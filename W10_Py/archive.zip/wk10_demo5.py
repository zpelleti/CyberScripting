
from genericpath import exists
from os import path
from os import rename

import shutil # this is for copy 
from shutil import make_archive
from zipfile import ZipFile

import python8

def main():
    filename = input ("Enter the source file name: ")
    print(filename)

    if not (path.exists(filename)):
        print ("calling wk10_demo4.main()")
        python8.main(filename)

    # make a duplicate of an existing file
    if path.exists(filename):
        # get the path to the file in the current directory
        src = path.realpath(filename);
        print ('src = {:10s}'.format(src))

        # # let's make a backup copy by appending "bak" to the name
        dst = src + ".bak"

        # # now use the shell to make a copy of the file (contents)
        shutil.copy(src,dst)
        
        
        # # rename the original file
        rename(filename, "new" + filename)
        
        # now put things into a ZIP archive
        root_dir,tail = path.split(src)
        print ('root_dir = {:10s}, tail = {:10s}'.format(root_dir,tail))
        shutil.make_archive("archive", "zip", root_dir)


        root_dir,tail = path.split(dst)  
        with ZipFile("myFiles.zip","w") as newzip:
            newzip.write("new" + filename)
            newzip.write(tail)                  # just the file
        
if __name__ == "__main__":
    main()
